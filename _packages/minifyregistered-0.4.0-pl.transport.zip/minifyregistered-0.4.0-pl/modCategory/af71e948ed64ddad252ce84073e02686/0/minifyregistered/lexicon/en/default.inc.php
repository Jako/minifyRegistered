<?php
/**
 * Default Lexicon Entries for minifyRegistered
 *
 * @package minifyregistered
 * @subpackage lexicon
 */
$_lang['minifyregistered'] = 'minifyRegistered';
